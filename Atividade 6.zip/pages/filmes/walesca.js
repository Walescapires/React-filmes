import React from 'react'

export const walesca = () => {
  return (
    <div>Walesca</div>
  )
}

export default walesca
